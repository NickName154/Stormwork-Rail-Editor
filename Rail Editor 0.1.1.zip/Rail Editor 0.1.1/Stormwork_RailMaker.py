import sys
import math
import re

from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QFileDialog,
    QGraphicsView, QGraphicsScene,
    QGraphicsEllipseItem, QGraphicsLineItem,
    QGraphicsRectItem,
    QGraphicsPolygonItem,
    QGraphicsProxyWidget,
    QPushButton, QWidget,
    QVBoxLayout, QHBoxLayout,
    QMessageBox
)

from PyQt6.QtGui import QPen, QBrush, QColor, QPainter, QPolygonF
from PyQt6.QtCore import Qt, QPointF

# =========================
# CONFIG
# =========================

TILE_SIZE = 1000
HALF = TILE_SIZE / 2
NODE_RADIUS = 2

# =========================
# GLOBAL STATE
# =========================

merge_map = {}
selected_tile = None

# =========================
# PLY PARSER
# =========================

def parse_ply(path):
    with open(path, "r") as f:
        lines = f.readlines()

    vcount = ecount = header_end = 0

    for i, line in enumerate(lines):
        if line.startswith("element vertex"):
            vcount = int(line.split()[-1])
        elif line.startswith("element edge"):
            ecount = int(line.split()[-1])
        elif line.strip() == "end_header":
            header_end = i + 1
            break

    vertices = [tuple(map(float, lines[header_end + i].split()[:3])) for i in range(vcount)]
    edges = [tuple(map(int, lines[header_end + vcount + i].split()[:2])) for i in range(ecount)]

    return vertices, edges

# =========================
# TILE SYSTEM
# =========================

def get_tile(x, y):
    return (round(x / TILE_SIZE), round(y / TILE_SIZE))


def get_root(tile):
    while tile in merge_map:
        tile = merge_map[tile]
    return tile

# =========================
# NODE
# =========================

class NodeItem(QGraphicsEllipseItem):
    def __init__(self, main, idx, x, y):
        super().__init__(-NODE_RADIUS, -NODE_RADIUS, NODE_RADIUS*2, NODE_RADIUS*2)
        self.main = main
        self.idx = idx

        self.setPos(x, y)
        self.setBrush(QBrush(QColor("red")))
        self.setPen(QPen(Qt.GlobalColor.black))

        self.setFlag(QGraphicsEllipseItem.GraphicsItemFlag.ItemIsSelectable, True)
        self.setAcceptedMouseButtons(Qt.MouseButton.LeftButton)

    def set_color(self, color):
        self.setBrush(QBrush(QColor(color)))

    def mousePressEvent(self, event):
        self.main.handle_node_click(self)

# =========================
# TILE
# =========================

class TileRect(QGraphicsRectItem):
    def __init__(self, tx, ty):
        x = tx * TILE_SIZE - HALF
        y = -ty * TILE_SIZE - HALF
        super().__init__(x, y, TILE_SIZE, TILE_SIZE)
        self.setPen(QPen(QColor(80, 80, 80), 1))
        self.setBrush(QBrush(QColor(40, 40, 40, 20)))

# =========================
# VIEW
# =========================

class View(QGraphicsView):
    def __init__(self, scene):
        super().__init__(scene)
        self.setRenderHint(QPainter.RenderHint.Antialiasing)
        self.setDragMode(QGraphicsView.DragMode.ScrollHandDrag)

    def wheelEvent(self, event):
        factor = 1.25 if event.angleDelta().y() > 0 else 0.8
        self.scale(factor, factor)

# =========================
# MAIN
# =========================

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("Stormworks Rail Editor - FINAL")

        self.scene = QGraphicsScene()
        self.view = View(self.scene)

        self.vertices = []
        self.edges = []
        self.nodes = {}
        self.tiles = {}
        self.adj = {}

        self.merge_arrows = {}

        self.active_junction = None
        self.green_node_by_junction = {}

        layout = QVBoxLayout()
        row = QHBoxLayout()

        load_btn = QPushButton("Load PLY")
        load_btn.clicked.connect(self.load_ply)

        clear_btn = QPushButton("Clear Tile.xml")
        clear_btn.clicked.connect(self.clear_tracks)

        row.addWidget(load_btn)
        row.addWidget(clear_btn)

        container = QWidget()
        layout.addLayout(row)
        layout.addWidget(self.view)
        container.setLayout(layout)

        self.setCentralWidget(container)

    # =========================
    # JUNCTION LOGIC
    # =========================

    def update_junction_colors(self):
        for idx, node in self.nodes.items():
            if len(self.adj.get(idx, [])) >= 3:
                node.set_color("blue")
            else:
                node.set_color("red")

    def handle_node_click(self, node):
        idx = node.idx

        if len(self.adj.get(idx, [])) >= 3:
            self.active_junction = idx
            return

        if self.active_junction is None:
            return

        if idx not in self.adj.get(self.active_junction, []):
            return

        junction = self.active_junction

        prev = self.green_node_by_junction.get(junction)
        if prev is not None and prev in self.nodes:
            self.nodes[prev].set_color("red")

        self.green_node_by_junction[junction] = idx
        node.set_color("green")

        self.active_junction = None

    # =========================
    # LOAD
    # =========================

    def load_ply(self):
        path, _ = QFileDialog.getOpenFileName(self, "PLY", "", "PLY (*.ply)")
        if not path:
            return

        self.vertices, self.edges = parse_ply(path)
        self.build_adj()
        self.build_scene()

    # =========================
    # ADJ
    # =========================

    def build_adj(self):
        self.adj = {}
        for a, b in self.edges:
            self.adj.setdefault(a, []).append(b)
            self.adj.setdefault(b, []).append(a)

    # =========================
    # TILE
    # =========================

    def build_tiles(self):
        self.tiles = {}
        for i, (x, y, z) in enumerate(self.vertices):
            tx, ty = get_tile(x, y)
            self.tiles.setdefault((tx, ty), []).append(i)

    # =========================
    # MERGE
    # =========================

    def merge_tile(self, tile):
        global selected_tile

        if selected_tile is None:
            selected_tile = tile
            return

        a = selected_tile
        b = tile
        selected_tile = None

        if a == b:
            return

        root_b = get_root(b)

        if a in merge_map and merge_map[a] == root_b:
            del merge_map[a]
            if (a, root_b) in self.merge_arrows:
                line, arrow = self.merge_arrows.pop((a, root_b))
                self.scene.removeItem(line)
                self.scene.removeItem(arrow)
            return

        merge_map[a] = root_b
        self.draw_merge_arrow(a, root_b)

    # =========================
    # MERGE ARROW
    # =========================

    def draw_merge_arrow(self, a, b):
        ax = a[0] * TILE_SIZE
        ay = -a[1] * TILE_SIZE

        bx = b[0] * TILE_SIZE
        by = -b[1] * TILE_SIZE

        line = QGraphicsLineItem(ax, ay, bx, by)
        line.setPen(QPen(QColor("black"), 2))

        angle = math.atan2(by - ay, bx - ax)
        size = 14

        p1 = QPointF(bx, by)
        p2 = QPointF(bx - size * math.cos(angle - 0.5), by - size * math.sin(angle - 0.5))
        p3 = QPointF(bx - size * math.cos(angle + 0.5), by - size * math.sin(angle + 0.5))

        arrow = QGraphicsPolygonItem(QPolygonF([p1, p2, p3]))
        arrow.setBrush(QBrush(QColor("black")))
        arrow.setPen(QPen(Qt.PenStyle.NoPen))

        self.scene.addItem(line)
        self.scene.addItem(arrow)

        self.merge_arrows[(a, b)] = (line, arrow)

    # =========================
    # SCENE
    # =========================

    def build_scene(self):
        global merge_map, selected_tile

        self.scene.clear()
        self.nodes.clear()

        merge_map.clear()
        selected_tile = None

        self.build_tiles()

        for (tx, ty) in self.tiles:
            tile = TileRect(tx, ty)
            self.scene.addItem(tile)

            base_x = tx * TILE_SIZE + HALF
            base_y = -ty * TILE_SIZE - HALF

            btn_size = 22
            pad = 6

            ebtn = QPushButton("E")
            ebtn.setFixedSize(btn_size, btn_size)
            ebtn.clicked.connect(lambda _, k=(tx, ty): self.export_tile(k))

            mbtn = QPushButton("M")
            mbtn.setFixedSize(btn_size, btn_size)
            mbtn.clicked.connect(lambda _, k=(tx, ty): self.merge_tile(k))

            ep = QGraphicsProxyWidget()
            ep.setWidget(ebtn)
            ep.setPos(base_x - btn_size * 2 - pad, base_y + pad)
            self.scene.addItem(ep)

            mp = QGraphicsProxyWidget()
            mp.setWidget(mbtn)
            mp.setPos(base_x - btn_size - pad, base_y + pad)
            self.scene.addItem(mp)

        for i, (x, y, z) in enumerate(self.vertices):
            node = NodeItem(self, i, x, -y)
            self.scene.addItem(node)
            self.nodes[i] = node

        for a, b in self.edges:
            self.scene.addItem(QGraphicsLineItem(
                self.nodes[a].x(), self.nodes[a].y(),
                self.nodes[b].x(), self.nodes[b].y()
            ))

        self.update_junction_colors()

    # =========================
    # CLEANER
    # =========================

    def clear_tracks(self):
        path, _ = QFileDialog.getOpenFileName(self, "Select tile.xml", "", "XML (*.xml)")
        if not path:
            return

        with open(path, "r", encoding="utf-8") as f:
            content = f.read()

        cleaned = re.sub(r"<track.*?>.*?</track>", "", content, flags=re.DOTALL)

        with open(path, "w", encoding="utf-8") as f:
            f.write(cleaned)

    # =========================
    # EXPORT
    # =========================

    def export_tile(self, tile_key):
        path, _ = QFileDialog.getSaveFileName(self, "Export XML", "", "XML (*.xml)")
        if not path:
            return

        root = get_root(tile_key)
        group = [t for t in self.tiles.keys() if get_root(t) == root]

        ox, oy = tile_key

        xml = ["<train_tracks>"]

        for tx, ty in group:
            for i in self.tiles[(tx, ty)]:
                x, y, z = self.vertices[i]

                lx = round(x - ox * TILE_SIZE, 3)
                ly = round(y - oy * TILE_SIZE, 3)
                lz = round(z, 3)

                xml.append(f'<track id="node_{i}">')
                links = self.adj.get(i, [])

                links = self.adj.get(i, [])

                if len(links) >= 3:
                    selected = self.green_node_by_junction.get(i)

                    if selected is not None and selected in links:
                        links = [n for n in links if n != selected] + [selected]

                xml.append("<links>")
                for n in links:
                    xml.append(f'<link id="node_{n}" />')
                xml.append("</links>")

                xml.append(
                    f'<transform 30="{lx:.3f}" 31="{lz:.3f}" 32="{ly:.3f}" />'
                )

                xml.append("</track>")

        xml.append("</train_tracks>")
        xml_block = "\n".join(xml)

        with open(path, "r", encoding="utf-8") as f:
            content = f.read()

        if "<train_tracks />" in content:
            content = content.replace("<train_tracks />", xml_block)

        elif "<train_tracks>" in content and "</train_tracks>" in content:
            content = re.sub(
                r"<train_tracks>.*?</train_tracks>",
                xml_block,
                content,
                flags=re.DOTALL
            )

        else:
            if "</definition>" in content:
                content = content.replace("</definition>", xml_block + "\n</definition>")
            else:
                content += "\n" + xml_block

        with open(path, "w", encoding="utf-8") as f:
            f.write(content)

        print("Exported:", tile_key)
# =========================
# RUN
# =========================

if __name__ == "__main__":
    app = QApplication(sys.argv)
    w = MainWindow()
    w.resize(1300, 900)
    w.show()
    sys.exit(app.exec())
